﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrudCSharpNoite.DAL
{
    public class PessoaDAO : intPessoaDAO
    {

        public void CadastrarPessoa(Modelo.Pessoa pessoa)
        {
            throw new NotImplementedException();
        }

        public Modelo.Pessoa PesquisarPessoaPorID(Modelo.Pessoa pessoa)
        {
            throw new NotImplementedException();
        }

        public void EditarPessoa(Modelo.Pessoa pessoa)
        {
            throw new NotImplementedException();
        }

        public void ExcluirPessoa(Modelo.Pessoa pessoa)
        {
            throw new NotImplementedException();
        }

        public List<Modelo.Pessoa> PesquisarPessoaPorNome(Modelo.Pessoa pessoa)
        {
            throw new NotImplementedException();
        }
    }
}
