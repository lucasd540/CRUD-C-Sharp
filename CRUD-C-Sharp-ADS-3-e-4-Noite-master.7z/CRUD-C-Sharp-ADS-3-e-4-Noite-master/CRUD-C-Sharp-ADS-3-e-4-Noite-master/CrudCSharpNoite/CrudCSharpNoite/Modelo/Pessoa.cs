﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrudCSharpNoite.Modelo
{
    public class Pessoa
    {
        public int id;
        public String nome;
        public String rg;
        public String cpf;
    }
}
